TextData1 <- read.csv("E:/Semester10/Data Science/FInal Term/Final Lab/Final_Project.csv")
TextData2 <- read.csv("E:/Semester10/Data Science/FInal Term/Final Lab/New_1.csv")
TextData <- rbind(TextData1, TextData2)
print(TextData)

install.packages("textclean")
library(textclean)

TextData$Data <- replace_contraction(TextData$Data)
TextData$Data <- replace_emoji(TextData$Data)
TextData$Data <- tolower(TextData$Data)
TextData$Data <- gsub("[[:punct:]]", "", TextData$Data)
TextData$Data <- gsub("[0-9]+", "", TextData$Data)
TextData$Data <- gsub("<.*?>", "", TextData$Data)
TextData$Data <- gsub("[^a-zA-Z0-9 ]", "", TextData$Data)

install.packages("tokenizers")
library(tokenizers)

TextData$Tokens <- tokenize_words(TextData$Data)

install.packages("tm")
library(tm)

TextData$No_Stop_Words <- lapply(TextData$Tokens, function(tokens) {
  tokens[!tokens %in% stopwords("en")]  
})

install.packages("SnowballC")
library(SnowballC)

TextData$Stemmed_Words <- lapply(TextData$No_Stop_Words, function(tokens) {
  wordStem(tokens, language = "en")
})

install.packages("textstem")
library(textstem)

TextData$Lemmatize_Words <- lapply(TextData$No_Stop_Words, function(tokens) {
  lemmatize_words(tokens)
})

install.packages("hunspell")
library(hunspell)

correct_spelling <- function(tokens) {
  corrected <- sapply(tokens, function(word) {
    if (hunspell_check(word)[1]) {
      return(word)
    } else {
      suggestions <- hunspell_suggest(word)
      if (length(suggestions[[1]]) > 0) {
        return(suggestions[[1]][1])
      } else {
        return(word)
      }
    }
  })
  return(corrected)
}

TextData$Corrected_Words <- lapply(TextData$Lemmatize_Words, correct_spelling)

Corrected_DataFrame <- data.frame(
  Text = sapply(TextData$Corrected_Words, paste, collapse = " "),
  stringsAsFactors = FALSE
)

corpus <- Corpus(VectorSource(Corrected_DataFrame$Text))
dtm <- DocumentTermMatrix(corpus)
inspect(dtm)

tfidf_dtm <- weightTfIdf(dtm)
inspect(tfidf_dtm)
tfidf_matrix <- as.matrix(tfidf_dtm)
tfidf_df <- as.data.frame(tfidf_matrix)
print(tfidf_df)

install.packages("topicmodels")
library(topicmodels)

lda_model <- LDA(dtm, k = 2, control = list(seed = 1234))

topics <- terms(lda_model, 35)
print(topics)

topic_probabilities <- posterior(lda_model)$topics
print(topic_probabilities)

TextData <- cbind(TextData, topics)
TextData <- cbind(TextData, topic_probabilities)

install.packages("openxlsx")
library(openxlsx)
write.xlsx(TextData, "H:/9.AIUB/DS/Project/Updated_Dataset.xlsx", rowNames = FALSE)